-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 07, 2019 at 03:53 PM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `labour`
--
CREATE DATABASE IF NOT EXISTS `labour` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `labour`;

-- --------------------------------------------------------

--
-- Table structure for table `accept_carpenter`
--

DROP TABLE IF EXISTS `accept_carpenter`;
CREATE TABLE IF NOT EXISTS `accept_carpenter` (
  `carpenter_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `phone_no` varchar(10) DEFAULT NULL,
  `wage_per_hour` int(11) DEFAULT NULL,
  `sqa` varchar(20) DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`carpenter_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1001 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accept_carpenter`
--

INSERT INTO `accept_carpenter` (`carpenter_id`, `name`, `password`, `phone_no`, `wage_per_hour`, `sqa`, `image`) VALUES
(1000, 'visa', 'vi', '097', 98, 'uhs', '');

-- --------------------------------------------------------

--
-- Table structure for table `accept_housekeeper`
--

DROP TABLE IF EXISTS `accept_housekeeper`;
CREATE TABLE IF NOT EXISTS `accept_housekeeper` (
  `housekeeper_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `phone_no` varchar(10) DEFAULT NULL,
  `wage_per_hour` int(11) DEFAULT NULL,
  `sqa` varchar(20) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`housekeeper_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3002 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accept_housekeeper`
--

INSERT INTO `accept_housekeeper` (`housekeeper_id`, `name`, `password`, `phone_no`, `wage_per_hour`, `sqa`, `image`) VALUES
(3000, 'mn', 'mn', '6776', 67, 'p', 'home_background.jpg'),
(3001, 'ad', 'ad', '876', 98798, '9879', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `accept_plumber`
--

DROP TABLE IF EXISTS `accept_plumber`;
CREATE TABLE IF NOT EXISTS `accept_plumber` (
  `plumber_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone_no` varchar(10) DEFAULT NULL,
  `wage_per_hour` int(11) DEFAULT NULL,
  `sqa` varchar(10) DEFAULT NULL,
  `image` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`plumber_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1002 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accept_plumber`
--

INSERT INTO `accept_plumber` (`plumber_id`, `name`, `password`, `phone_no`, `wage_per_hour`, `sqa`, `image`) VALUES
(1000, 'ullas', 'ul', '6876678', 675, 'jh', 'home_background.jpg'),
(1001, 'figi', 'figi', '345', 45, 'tuna', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
CREATE TABLE IF NOT EXISTS `feedback` (
  `fname` varchar(10) DEFAULT NULL,
  `lname` varchar(10) DEFAULT NULL,
  `msg` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`fname`, `lname`, `msg`) VALUES
('Sharath', 'Kumar', 'Nice Project!!');

-- --------------------------------------------------------

--
-- Table structure for table `request_carpenter`
--

DROP TABLE IF EXISTS `request_carpenter`;
CREATE TABLE IF NOT EXISTS `request_carpenter` (
  `name` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `phone_no` varchar(50) DEFAULT NULL,
  `wage_per_hour` int(11) DEFAULT NULL,
  `sqa` varchar(20) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `request_housekeeper`
--

DROP TABLE IF EXISTS `request_housekeeper`;
CREATE TABLE IF NOT EXISTS `request_housekeeper` (
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `phone_no` varchar(10) DEFAULT NULL,
  `wage_per_hour` int(11) DEFAULT NULL,
  `sqa` varchar(20) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `request_plumber`
--

DROP TABLE IF EXISTS `request_plumber`;
CREATE TABLE IF NOT EXISTS `request_plumber` (
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone_no` varchar(10) DEFAULT NULL,
  `wage_per_hour` int(11) DEFAULT NULL,
  `sqa` varchar(10) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_carpenter`
--

DROP TABLE IF EXISTS `user_carpenter`;
CREATE TABLE IF NOT EXISTS `user_carpenter` (
  `user_id` int(11) NOT NULL,
  `carpenter_id` int(11) NOT NULL,
  `status` varchar(2) DEFAULT NULL,
  `view_status` varchar(4) DEFAULT NULL,
  `book_date` varchar(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_housekeeper`
--

DROP TABLE IF EXISTS `user_housekeeper`;
CREATE TABLE IF NOT EXISTS `user_housekeeper` (
  `user_id` int(11) NOT NULL,
  `housekeeper_id` int(11) NOT NULL,
  `status` varchar(3) DEFAULT NULL,
  `view_status` varchar(3) DEFAULT NULL,
  `book_date` varchar(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

DROP TABLE IF EXISTS `user_info`;
CREATE TABLE IF NOT EXISTS `user_info` (
  `name` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  `address` varchar(200) DEFAULT NULL,
  `phn_no` varchar(11) NOT NULL,
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `sqa` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=103 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`name`, `password`, `address`, `phn_no`, `user_id`, `sqa`) VALUES
('surya', 'sur', 'iyfy', '12345', 100, 'dosa'),
('ullas', 'ull', 'gjdjg', '76576', 101, 'hdfhdf'),
('mj', 'mjn', 'jsdfjdsk', '38572485', 102, 'pizza');

-- --------------------------------------------------------

--
-- Table structure for table `user_plumber`
--

DROP TABLE IF EXISTS `user_plumber`;
CREATE TABLE IF NOT EXISTS `user_plumber` (
  `user_id` int(11) NOT NULL,
  `plumber_id` int(11) NOT NULL,
  `status` varchar(4) DEFAULT NULL,
  `view_status` varchar(2) DEFAULT NULL,
  `book_date` varchar(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
